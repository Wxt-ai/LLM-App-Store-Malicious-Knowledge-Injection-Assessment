import json
import csv

# 定义输入的JSON文件路径和输出的CSV文件路径
input_file = "malicious_LLM_responses/Poe/QA-Poe-1.json"
output_file = "malicious_LLM_responses/Poe/QA-Poe-1.csv"

# 读取JSON文件
with open(input_file, "r", encoding="utf-8-sig") as f:
    data = [json.loads(line) for line in f]

# 提取表头（JSON的键）
keys = data[0].keys()

# 写入CSV文件
with open(output_file, "w", encoding="utf-8-sig", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=keys)
    writer.writeheader()  # 写入表头
    writer.writerows(data)  # 写入内容

print(f"CSV文件已成功生成，路径为: {output_file}")
