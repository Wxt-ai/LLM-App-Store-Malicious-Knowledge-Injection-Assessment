from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from lxml import html
import time
import csv

# 自动下载和配置chromedriver
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

url = "https://flowgpt.com/zh-CN"

# 获取网页内容
driver.get(url)
time.sleep(3)  # 等待页面加载完成

# 获取页面源代码
html_content = driver.page_source
driver.quit()

# 使用lxml解析网页内容
tree = html.fromstring(html_content)

# 定义一个列表存储所有app信息
apps_data = []

# 获取每个app的条目
app_elements = tree.xpath('//*[@id="scrollableDiv"]/div/div[2]/div[2]/ul/li')

# 遍历每个li标签提取app的名称和描述
for app in app_elements:
    try:
        # 提取app名称
        app_name = app.xpath('.//div/div[4]/div/div/a/span/h2/text()')
        if app_name:
            app_name = app_name[0].strip()
        else:
            app_name = "没有名称"  # 如果没有名称，则设置默认值

        # 提取app描述
        app_desc = app.xpath('.//div/div[4]/div/div/a/span/p/text()')
        if app_desc:
            app_desc = app_desc[0].strip()
        else:
            app_desc = "没有描述"  # 如果没有描述，则设置默认值

        # 保存数据
        apps_data.append([app_name, app_desc])
    except IndexError:
        # 如果遇到没有名称或描述的app，跳过该app
        continue

# 将数据写入CSV文件
with open('apps_info.csv', mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    # 写入表头
    writer.writerow(['App Name', 'Description'])
    # 写入每一行数据
    writer.writerows(apps_data)

print(f"爬取完成，共爬取到 {len(apps_data)} 个app信息。")
