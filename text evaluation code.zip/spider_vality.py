import csv
import time  # 引入 time 模块
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 配置 ChromeDriver
driver = webdriver.Chrome()

# 输入 CSV 文件名
input_csv = "malicious_LLM_name_list/malicious_LLM_applications_on_Poe.csv"

# 输出结果的 CSV 文件
output_csv = "output_urls_validity.csv"

# 设置每次请求之间的间隔时间（以秒为单位）
DELAY_BETWEEN_REQUESTS = 5  # 可根据需要调整间隔时间，例如 5 秒

# 打开 CSV 文件读取 URL 并提取目标元素
results = []
with open(input_csv, mode='r', encoding='utf-8') as infile:
    reader = csv.DictReader(infile)
    fieldnames = reader.fieldnames + ['validity']  # 新增 validity 列

    for row in reader:
        url = row['URL']  # 假设 CSV 文件有一列名为 'URL'
        print(f"Processing URL: {url}")

        try:
            # 打开网页
            driver.get(url)

            # 等待目标元素加载完成
            try:
                element = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, "//h1[@class='StatusCodeError_statusCode__M4knP']"))
                )
                status_code = element.text  # 获取元素的文本值
            except Exception:
                status_code = "Not Found"

            print(f"Status Code: {status_code}")

            # 根据状态码设置 validity 列的值
            if status_code == "404":
                row['validity'] = 0
            else:
                row['validity'] = 1

        except Exception as e:
            print(f"Error processing {url}: {e}")
            row['validity'] = 0  # 如果加载出错，标记为无效

        results.append(row)

        # 在每次请求之间设置间隔时间
        print(f"Waiting {DELAY_BETWEEN_REQUESTS} seconds before processing the next URL...")
        time.sleep(DELAY_BETWEEN_REQUESTS)

# 写入结果到新的 CSV 文件
with open(output_csv, mode='w', encoding='utf-8', newline='') as outfile:
    writer = csv.DictWriter(outfile, fieldnames=fieldnames)
    writer.writeheader()  # 写入表头
    writer.writerows(results)  # 写入数据

print(f"Results saved to {output_csv}")

# 关闭浏览器
driver.quit()
