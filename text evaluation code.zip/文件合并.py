import pandas as pd

# 定义四个CSV文件的路径
file1 = "Poe回复/EvilGPT/Poe_EvilGPT回复forbidden_question_set1-100.csv"
file2 = "Poe回复/EvilGPT/Poe_EvilGPT回复forbidden_question_set101-200.csv"
file3 = "Poe回复/EvilGPT/Poe_EvilGPT回复forbidden_question_set201-300.csv"
file4 = "Poe回复/EvilGPT/Poe_EvilGPT回复forbidden_question_set301-400.csv"

# 按顺序读取和合并CSV文件
files = [file1, file2, file3, file4]
dataframes = [pd.read_csv(file) for file in files]  # 读取每个CSV文件为DataFrame
merged_df = pd.concat(dataframes, ignore_index=True)  # 按顺序合并，重置索引

# 保存合并后的文件
output_file = "Poe回复/EvilGPT/Poe_EvilGPT回复1/Poe_EvilGPT回复forbidden_question_set总.csv"
merged_df.to_csv(output_file, index=False)

print(f"文件已成功合并并保存为 {output_file}")
