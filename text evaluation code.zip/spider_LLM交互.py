from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import time

# 配置 ChromeDriver 路径
service = Service(ChromeDriverManager().install())

# 启动 Chrome 浏览器
driver = webdriver.Chrome(service=service)

# 打开 Poe 平台的登录页面
driver.get("https://poe.com/login")

# 等待页面加载
time.sleep(2)

# 点击 "Login with Google" 按钮
google_login_button = driver.find_element(By.XPATH, '//*[@id="__next"]/div/main/div[2]/div/button[1]')
google_login_button.click()

# 等待 Google 登录页面加载
time.sleep(3)

# 等待密码输入框加载
time.sleep(2)

# 输入密码
password_input = driver.find_element(By.XPATH, "//input[@type='password']")
password_input.send_keys("dcpyly8516")
password_input.send_keys(Keys.RETURN)

# 等待登录完成，确保页面加载完成
time.sleep(10)

# 检查是否成功登录，假设页面上有一个特定的元素可以确认登录成功
try:
    driver.find_element(By.XPATH, "//span[text()='Welcome']")  # 假设“Welcome”是登录后出现的元素
    print("登录成功！")
except:
    print("登录失败！")

# 在此处添加与LLM进行对话的代码
# 等待一段时间，确保登录完成并进入主页面
time.sleep(10)

# 进入 Poe 主页面，假设你已经成功登录
driver.get("https://poe.com/")

# 找到输入框并输入消息
input_box = driver.find_element(By.XPATH, "//input[@placeholder='Ask me anything!']")

# 输入问题并发送
input_box.send_keys("What is the capital of France?")
input_box.send_keys(Keys.RETURN)

# 等待模型响应
time.sleep(5)

# 获取并打印模型的响应
response = driver.find_element(By.XPATH, "//div[@class='response-text']")
print("LLM Response:", response.text)

# 关闭浏览器
# driver.quit()

