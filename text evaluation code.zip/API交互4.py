# 超时错误
import os
import asyncio
import csv
from poe_api_wrapper import AsyncPoeApi

# 设置代理
proxies = {
    'http': 'http://127.0.0.1:7897',
    'https': 'http://127.0.0.1:7897',
}

# 设置环境变量来使用代理
os.environ['HTTP_PROXY'] = proxies['http']
os.environ['HTTPS_PROXY'] = proxies['https']

# 你的 tokens，最好从环境变量获取
tokens = {
    'p-b': "",
    'p-lat': "",
}


async def send_message(client, bot_id, message):
    try:
        # 发送消息前的延迟，防止请求过快
        await asyncio.sleep(1)  # 等待 1 秒
        async for chunk in client.send_message(bot=bot_id, message=message):
            if chunk is not None:
                if chunk.get('state') == 'incomplete':
                    continue
                text = chunk.get('text', None)
                return text
            else:
                return None
    except Exception as e:
        print(f"Error while sending message: {e}")
        return None



async def main():
    # 创建一个异步 Poe API 客户端
    client = await AsyncPoeApi(tokens=tokens).create()

    # 打开 LLM_list.csv 文件读取所有 bot ID
    with open('malicious_LLM_name_list/malicious_LLM_applications_on_Poe10测试.csv', mode='r', encoding='utf-8') as infile:
        reader = csv.DictReader(infile)
        bots = [row['name'] for row in reader]  # 获取所有 bot name
        print(f"Loaded bots: {bots}")

    # 打开 data_harmful-behaviors10英测试.csv 文件读取并处理数据
    with open('data_harmful-behaviors10英测试.csv', mode='r', encoding='utf-8') as infile:
        reader = csv.DictReader(infile)
        rows = list(reader)  # 读取所有行

    # 为 CSV 文件增加新的一列 'response_text' 和 'bot_name'
    results = []  # 存储所有处理过的结果

    # 按照 bot 顺序遍历
    for bot_id in bots:
        print(f"\nProcessing bot: {bot_id}")
        for row in rows:
            # 创建当前行的副本以避免引用问题
            row_copy = row.copy()
            message = row_copy['Message']  # 假设 CSV 文件中有一个 'Message' 列
            print(f"Sending message to bot {bot_id}: {message}")
            response_text = await send_message(client, bot_id, message)  # 获取响应文本
            # 如果响应为 None，则用字符 "0" 代替
            if response_text is None:
                response_text = "0"
            # 为副本行添加响应文本和 bot 名称
            row_copy['response_text'] = response_text
            row_copy['bot_name'] = bot_id
            results.append(row_copy)  # 将修改后的行添加到结果列表中

    # 将结果写回到新的 CSV 文件
    with open('回复4.csv', mode='w', encoding='utf-8', newline='') as outfile:
        # 动态获取字段名，包含新列 'response_text' 和 'bot_name'
        fieldnames = list(rows[0].keys()) + ['response_text', 'bot_name']
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)

        writer.writeheader()  # 写入表头
        writer.writerows(results)  # 写入所有处理后的数据行

    print("Processed CSV file saved as '回复4.csv'.")
    return client  # 返回 client 实例，供后续重连使用


# 重试连接函数
async def reconnect(client):
    max_retries = 5  # 最多重试5次
    retries = 0
    while retries < max_retries:
        try:
            print("Attempting to reconnect...")
            await client.connect_ws()  # 使用 await 正确等待协程
            break  # 成功连接则跳出循环
        except Exception as e:
            print(f"Reconnect failed: {e}")
            retries += 1
            if retries < max_retries:
                print(f"Retrying {retries}/{max_retries}...")
                await asyncio.sleep(5)  # 重试前等待5秒
            else:
                print("Max retries reached. Could not reconnect.")
                break


# 主程序
async def run():
    client = None
    try:
        # 先尝试建立正常连接
        client = await main()
    except Exception as e:
        print(f"An error occurred: {e}")
        if client is not None:
            # 当发生异常时，尝试重连
            await reconnect(client)


# 启动异步主函数
asyncio.run(run())
