import os
import asyncio
import csv
from poe_api_wrapper import AsyncPoeApi

# 设置代理
proxies = {
    'http': 'http://127.0.0.1:7897',
    'https': 'http://127.0.0.1:7897',
}

# 设置环境变量来使用代理
os.environ['HTTP_PROXY'] = proxies['http']
os.environ['HTTPS_PROXY'] = proxies['https']

# 你的 tokens，最好从环境变量获取
tokens = {
    'p-b': "",
    'p-lat': "",
}


async def send_message(client, message):
    try:
        # 发送消息并获取响应
        async for chunk in client.send_message(bot="EvilGPT", message=message):
            if chunk is not None:
                # 检查 'state' 是否是 'incomplete'，如果是，跳过处理
                if chunk.get('state') == 'incomplete':
                    continue

                # 输出 'text' 字段内容
                text = chunk.get('text', '')
                if text:
                    print(text, end='', flush=True)  # 输出 text，避免换行
                else:
                    print("No 'text' field found or it's empty:", chunk)
            else:
                print("Received an empty chunk:", chunk)
    except Exception as e:
        print(f"Error while sending message: {e}")


async def main():
    # 创建一个异步 Poe API 客户端
    client = await AsyncPoeApi(tokens=tokens).create()

    # 从 CSV 文件中批量读取消息并发送
    with open('data_harmful-behaviors10英测试.csv', mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            message = row['Message']  # 假设 CSV 文件中有一个 'message' 列
            print(f"\nSending message: {message}")
            await send_message(client, message)

    return client  # 返回 client 实例，供后续重连使用


# 重试连接函数
async def reconnect(client):
    max_retries = 5  # 最多重试5次
    retries = 0
    while retries < max_retries:
        try:
            print("Attempting to reconnect...")
            await client.connect_ws()  # 使用 await 正确等待协程
            break  # 成功连接则跳出循环
        except Exception as e:
            print(f"Reconnect failed: {e}")
            retries += 1
            if retries < max_retries:
                print(f"Retrying {retries}/{max_retries}...")
                await asyncio.sleep(5)  # 重试前等待5秒
            else:
                print("Max retries reached. Could not reconnect.")
                break


# 主程序
async def run():
    client = None
    try:
        # 先尝试建立正常连接
        client = await main()
    except Exception as e:
        print(f"An error occurred: {e}")
        if client is not None:
            # 当发生异常时，尝试重连
            await reconnect(client)


# 启动异步主函数
asyncio.run(run())
