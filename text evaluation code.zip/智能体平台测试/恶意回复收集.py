import os
import asyncio
import csv
from poe_api_wrapper import AsyncPoeApi

# 设置代理
proxies = {
    'http': 'http://127.0.0.1:7897',
    'https': 'http://127.0.0.1:7897',
}

# 设置环境变量来使用代理
os.environ['HTTP_PROXY'] = proxies['http']
os.environ['HTTPS_PROXY'] = proxies['https']

# 你的 tokens，最好从环境变量获取
tokens = {
    'p-b': "4caNyHd9x5ZzpzoN2YIbeA%3D%3D",
    'p-lat': "SirXiKdZPceasIGICtnmBi6BF%2B95sNAW02d3lRPvOw%3D%3D",
}


async def send_message(client, message):
    try:
        # 发送消息并获取响应
        async for chunk in client.send_message(bot="BAOKONG", message=message):
            if chunk is not None:
                # 检查 'state' 是否是 'incomplete'，如果是，跳过处理
                if chunk.get('state') == 'incomplete':
                    continue

                # 输出 'text' 字段内容
                text = chunk.get('text', '')
                return text  # 返回 text 字段
            else:
                return "No response received"  # 如果没有响应
    except Exception as e:
        print(f"Error while sending message: {e}")
        return "Error occurred"


async def main():
    # 创建一个异步 Poe API 客户端
    client = await AsyncPoeApi(tokens=tokens).create()

    # 打开 CSV 文件读取并处理数据
    with open('暴恐.csv', mode='r', encoding='utf-8') as infile:
        reader = csv.DictReader(infile)
        rows = list(reader)  # 读取所有行

    # 为 CSV 文件增加新的一列 'response_text'
    for row in rows:
        message = row['question']  # 假设 CSV 文件中有一个 'message' 列
        print(f"\nSending message: {message}")
        response_text = await send_message(client, message)  # 获取响应文本
        row['reply'] = response_text  # 将响应文本存储到 'response_text' 列

    # 将结果写回到新的 CSV 文件
    with open('暴恐回复.csv', mode='w', encoding='utf-8', newline='') as outfile:
        fieldnames = reader.fieldnames + ['reply']  # 新的列名
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)

        writer.writeheader()  # 写入表头
        writer.writerows(rows)  # 写入所有数据行

    print("Processed CSV file saved as '暴恐响应.csv'.")
    return client  # 返回 client 实例，供后续重连使用


# 重试连接函数
async def reconnect(client):
    max_retries = 5  # 最多重试5次
    retries = 0
    while retries < max_retries:
        try:
            print("Attempting to reconnect...")
            await client.connect_ws()  # 使用 await 正确等待协程
            break  # 成功连接则跳出循环
        except Exception as e:
            print(f"Reconnect failed: {e}")
            retries += 1
            if retries < max_retries:
                print(f"Retrying {retries}/{max_retries}...")
                await asyncio.sleep(5)  # 重试前等待5秒
            else:
                print("Max retries reached. Could not reconnect.")
                break


# 主程序
async def run():
    client = None
    try:
        # 先尝试建立正常连接
        client = await main()
    except Exception as e:
        print(f"An error occurred: {e}")
        if client is not None:
            # 当发生异常时，尝试重连
            await reconnect(client)


# 启动异步主函数
asyncio.run(run())
