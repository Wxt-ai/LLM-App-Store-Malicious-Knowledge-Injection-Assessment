import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager  # 导入 webdriver-manager

# 配置 ChromeOptions（例如无头模式）
options = Options()
# options.add_argument('--headless')  # 启动无头模式（可选）
# options.add_argument('--disable-extensions')  # 禁用扩展（可选）

# 自动下载和配置 chromedriver
service = Service(ChromeDriverManager().install())  # 自动下载并获取对应版本的 chromedriver

# 启动浏览器
browser = webdriver.Chrome(service=service, options=options)

# 打开网页
browser.get('https://www.taobao.com/')

# 等待几秒钟以确保页面加载
time.sleep(5)

# 浏览器将保持打开状态，直到你手动关闭它
# 删除或注释掉下面的 line 以确保浏览器保持打开状态
# browser.quit()
